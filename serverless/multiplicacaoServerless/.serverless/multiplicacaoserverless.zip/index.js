exports.multiplica = require('./funcoes/multiplica')
exports.recebeOpMultiplicacao = require('./funcoes/recebeOpMultiplicacao')